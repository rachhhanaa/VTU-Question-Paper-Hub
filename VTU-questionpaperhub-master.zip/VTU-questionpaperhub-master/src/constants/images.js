import header_bg from "../assets/images/header-bg.jpg";

export default{
    header_bg,
    
};